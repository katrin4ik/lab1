package com.example.lab1;

public class Constants {
    public static final String KEY_MESSAGE = "key";
}
